package utility;

public class Constants {
	public static int restaurantDistance = 25;
	public static int gridWidth = 1000;
	public static int gridHeight = 1000;
}
