package main;

import evaluationLayer.Simulation;

public class SimulMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Simulation simul = new Simulation(); 
		simul.stream();

	}

}
