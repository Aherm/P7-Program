package main;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import businessLogicLayer.Filter;
import dataAccessLayer.DBConnect;
import dataAccessLayer.DBGetTweets;
import dataAccessLayer.DBInsert;
import evaluationLayer.Simulation;
import modelLayer.Tweet;
import modelLayer.TweetStorage;
import streaming.TwitterRest;
import testLayer.GridTest;
import twitter4j.TwitterException;

public class localMain {

	public static void main(String[] args) throws Exception {
		//GridTest.runTest();
		
		
		
		Simulation simul = new Simulation();
		simul.stream();
		
		
	}
}
