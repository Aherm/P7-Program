package modelLayer;

public interface OurLocation {
	public double getLat();
	public double getLon();
	public void setLat(double lat);
	public void setLon(double lon);
}