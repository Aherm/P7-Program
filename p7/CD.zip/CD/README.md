# P7-Program
The program is started by running Program.jar in a terminal. "java -jar Program.jar"
While the program is running, inputting "1" into console will result in outputting the amount of tweets to console.
Inputting "2" into console will result in outputting the of score restaurants to the console.